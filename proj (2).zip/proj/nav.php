<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar with Icons and Cart</title>
    <!-- Font Awesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" href="nav.css">
     <!-- JavaScript -->
     <script src="nav.js"></script>
</head>
<body>
    <!-- Navbar starts -->
                                            <!-- Navbar starts -->
                                          
                                        <div class="navbarnew">
                                            <div class="logonew">
                                                <img src="photo/logo.png" alt="Logo">
                                                <span>Pet Pantry</span>
                                            </div>
                                            <div class="nav-linksnew">
                                                <a href="home.php"><i class="fas fa-home"></i> Home</a>
                                                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                                                <a href="prod.php"><i class="fas fa-box"></i> Products</a>
                                                <a href="acc.php"><i class="fas fa-cogs"></i> Accessories</a>
                                                <a href="review.php"><i class="fas fa-comments"></i> Review</a>
                                                <div class="dropdownnew">
                                                    <a href="#shop"><i class="fas fa-shopping-cart"></i> Shop <i class="fas fa-chevron-down"></i></a>
                                                    <div class="dropdown-menunew">
                                                        <a href="#shop-cat">Cat</a>
                                                        <a href="#shop-dog">Dog</a>
                                                        <a href="#shop-bird">Bird</a>
                                                        <a href="#shop-turtle">Turtle</a>
                                                        <a href="#shop-rabbit">Rabbit</a>
                                                        <a href="#shop-fish">Fish</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="account-linksnew">
                                                <button onclick="login()"><i class="fas fa-sign-in-alt"></i> <a href="login.php">Login</a></button>
                                                <button onclick="signup()"><i class="fas fa-user-plus"></i> <a href="login.php">Sign Up</a></button>
                                                <div class="cartnew">
                                                    <i class="fas fa-shopping-cart"></i>
                                                    <span class="cart-countnew">0</span>
                                                </div>
                                            </div>
                                        </div>

                                        


                                        <!-- Navbar ends -->

    <!-- Navbar ends -->

   
</body>
</html>
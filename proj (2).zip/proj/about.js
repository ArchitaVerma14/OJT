
                                const navBar = document.querySelector('.navbar');
                                const openMenuToggle = document.querySelector('.bx-menu');
                                const closeMenuToggle = document.querySelector('.bx-x');
                                const homeImage = document.querySelector('.img_home');

                       // --- OPEN MENU

                                openMenuToggle.addEventListener('click', () => {
                                    if(navBar.classList.contains('show_navbar')){
                                        navBar.classList.remove('show_navbar');
                                    }else {
                                        navBar.classList.add('show_navbar');
                                        openMenuToggle.classList.add("hide");
                                        closeMenuToggle.classList.add("show");
                                    }
                                })

                      // --- CLOSE MENU

                                closeMenuToggle.addEventListener('click', () => {
                                    if(navBar.classList.contains('show_navbar')){
                                        navBar.classList.remove('show_navbar');
                                        openMenuToggle.classList.remove("hide");
                                        closeMenuToggle.classList.remove("show");
                                    }
                                })

                        // Change desktop image based on device width

                                const imageMobile = 'https://github.com/r-e-d-ant/DOG-guard-website/blob/main/assets/images/dog_mobile_pink.png?raw=true';
                                const imageDesktop = 'https://github.com/r-e-d-ant/DOG-guard-website/blob/main/assets/images/dog_image_in_blob.png?raw=true';

                                const changeHomeImage = (x) => {
                                  if(x.matches){
                                    homeImage.src = imageDesktop;
                                  }else {
                                    homeImage.src = imageMobile;
                                  }
                                }
                                const x = window.matchMedia('(min-width: 780px)');
                                changeHomeImage(x)
                                x.addListener(changeHomeImage);


                 // --------- DARK MODE ACTIVATION ----------
                                let darkMode = localStorage.getItem('whitemode');
                                const darkModeToggle = document.querySelector('.themecolor');
                                const sunIcon = document.querySelector('.bxs-sun');
                                const moonIcon = document.querySelector('.bxs-moon');

                                const enableDarkMode = () => {
                         // 1. Add the class dark mode to the body
                                    document.body.classList.add('whitemode');
                         // 2. Update dark mode in the local storage
                                    localStorage.setItem('whitemode', 'enabled');
                                }

                                if (darkMode === "enabled"){
                                    enableDarkMode();
                                    sunIcon.classList.add("hide");
                                    moonIcon.classList.add("show");
                                }

                                const disableDarkMode = () => {
                        // 1. Remove class dark mode to the body
                                    document.body.classList.remove('whitemode');
                                    localStorage.setItem('whitemode', null)
                                }

                                darkModeToggle.addEventListener('click', () => {
                                    darkMode = localStorage.getItem('whitemode');
                                    if (darkMode !== "enabled"){
                                        enableDarkMode();
                                        sunIcon.classList.add("hide");
                                        moonIcon.classList.add("show");
                                    }else {
                                        disableDarkMode();
                                        sunIcon.classList.remove("hide");
                                        moonIcon.classList.remove("show");
                                    }
                                })












                                // 
                                function init() { 
                                    const catWrapper = document.querySelector('.cat_wrapper')
                                    const wrapper = document.querySelector('.wrapper')
                                    const cat = document.querySelector('.cat')
                                    const head = document.querySelector('.cat_head')
                                    const legs = document.querySelectorAll('.leg')
                                    const pos = {
                                      x: null,
                                      y: null
                                    }
                                  
                                    const walk = () =>{
                                      cat.classList.remove('first_pose')
                                      legs.forEach(leg=>leg.classList.add('walk'))
                                    }
                                  
                                    const handleMouseMotion = e =>{
                                      pos.x = e.clientX
                                      pos.y = e.clientY
                                      walk()
                                    }
                                  
                                    const handleTouchMotion = e =>{
                                      if (e.targetTouches) return
                                      
                                      pos.x = e.targetTouches[0].offsetX
                                      pos.y = e.targetTouches[0].offsetY
                                      walk()
                                    }
                                  
                                    const turnRight = () =>{
                                      cat.style.left = `${pos.x - 90}px`
                                      cat.classList.remove('face_left')
                                      cat.classList.add('face_right')
                                    }
                                  
                                    const turnLeft = () =>{
                                      cat.style.left = `${pos.x + 10}px`
                                      cat.classList.remove('face_right')
                                      cat.classList.add('face_left')
                                    }
                                  
                                    const decideTurnDirection = () =>{
                                      cat.getBoundingClientRect().x < pos.x ?
                                        turnRight()
                                        :
                                        turnLeft()
                                    }
                                  
                                    const headMotion = () =>{
                                      pos.y > (wrapper.clientHeight - 100) ?
                                        head.style.top = '-15px'
                                        :
                                        head.style.top = '-30px'
                                    }
                                  
                                    const jump = () =>{
                                      catWrapper.classList.remove('jump')
                                      if (pos.y < (wrapper.clientHeight - 250)) {
                                        setTimeout(()=>{
                                          catWrapper.classList.add('jump')
                                        },100)
                                      } 
                                    }
                                  
                                    const decideStop = ()=>{
                                      if (cat.classList.contains('face_right') && pos.x - 90 === cat.offsetLeft ||
                                          cat.classList.contains('face_left') && pos.x + 10 === cat.offsetLeft) {
                                        legs.forEach(leg=>leg.classList.remove('walk'))    
                                      }
                                    }
                                    
                                    setInterval(()=>{
                                      if (!pos.x || !pos.y) return
                                      decideTurnDirection()
                                      headMotion()
                                      decideStop()
                                    },100)
                                  
                                    setInterval(()=>{
                                      if (!pos.x || !pos.y) return
                                      jump()
                                    },1000)
                                  
                                    document.addEventListener('mousemove', handleMouseMotion)
                                    document.addEventListener('mousemove', handleTouchMotion)
                                  }
                                  
                                  window.addEventListener('DOMContentLoaded', init)
                                // 













                
 // navbar starts 
                                        // Login functionality
                                        function login() {
                                          alert('Redirecting to login page...');
                                      }
                                      
                                      // Sign-Up functionality
                                      function signup() {
                                          alert('Redirecting to sign-up page...');
                                      }
                                      
                                      // Simulate adding items to cart
                                      let cartCount = 0;
                                      
                                      function addToCart() {
                                          cartCount++;
                                          document.querySelector('.cart-count').textContent = cartCount;
                                      }
                                      
                                      // Example: Simulate adding an item after 3 seconds
                                      setTimeout(addToCart, 3000);
              
// navbar ends
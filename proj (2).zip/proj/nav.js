//   navbar starts
                         // Login functionality
                                function login() {
                                    alert('Redirecting to login page...');
                                }

                                // Sign-Up functionality
                                function signup() {
                                    alert('Redirecting to sign-up page...');
                                }

                                // Simulate adding items to cart
                                let cartCount = 0;

                                function addToCart(itemName = "Default Item") {
                                    cartCount++;
                                    document.querySelector('.cart-countnew').textContent = cartCount;

                                    // Append new item to the cart list
                                    const cartList = document.querySelector('#cart-list');
                                    const newItem = document.createElement('li');
                                    newItem.textContent = `${itemName} added to cart`;
                                    cartList.appendChild(newItem);
                                }

                                // Example: Simulate adding an item after 3 seconds
                                setTimeout(() => addToCart("Example Item"), 3000);
// navbar ends
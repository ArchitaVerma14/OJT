<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
        <title>about us</title>
        <link rel="stylesheet" href="about.css">
        <script src="about.js" defer></script>
      </head>
      







      <body>


 <!-- navbar starts -->
                        <!-- navbar -->
<?php include("nav.php"); ?>
<!-- navbar ends -->







<!-- ======== HEADER ======== -->
                            <header id="header">
                              <div class="open_close_menu__container">
                                <i class="bx bx-menu"></i>
                                <i class="bx bx-x"></i>
                              </div>
                            </header>
<!-- HEADER CLOSE -->

<!-- ======== MAIN ======== -->
        
<!-- SECTION 1 -->
      <main>
                            <section id="home" class="section_0 container">
                              <div class="section_1">
                                <div class="home_slogan">
                                  <h1 class="company_name title">Who We Are</h1>
                                  <div class="slogan_text text">Nourishing Pets, One Bowl at a Time <BR> At The Pet Pantry, we serve up love, nutrition, and happiness, one bowl and accessory at a time!</div>
                                </div>
                                <div class="home__image_mobile">
                                  <img class="img_home" src="" alt="">
                                </div>
                              </div>
                        
                              <div class="bones">
                                <i class="fas fa-bone bone1"></i>
                                <i class="fas fa-bone bone2"></i>
                                <i class="fas fa-bone bone3"></i>
                                <i class="fas fa-bone bone4"></i>
                              </div>
                              <div class="paws">
                                <i class="fas fa-paw paw1"></i>
                                <i class="fas fa-paw paw2"></i>
                                <i class="fas fa-paw paw3"></i>
                                <i class="fas fa-paw paw4"></i>
                                <i class="fas fa-paw paw5"></i>
                                <i class="fas fa-paw paw6"></i>
                                <i class="fas fa-paw paw7"></i>
                              </div>
                            </section>
<!-- SECTION 1 ENDS -->













<!-- SECTION 2 -->
                                  <section id="services" class="section_2 container">
                                    <h2 class="services title">SERVICES</h2>
                                    <div class="services__container">
                                      <div class="service service_1">
                                        <img src="https://github.com/r-e-d-ant/DOG-guard-website/blob/main/assets/images/ser_dog_1.png?raw=true" alt="dog reading a book">
                                        <div class="service_description">
                                          <h3 class="service_title">Food:</h3>
                                          <p>Give Your Pet the Best: Nutrient-Rich, Tail-Wagging Meals Crafted with Love!</p>
                                        </div>
                                      </div>
                                      <div class="service service_2">
                                        <img src="https://github.com/r-e-d-ant/DOG-guard-website/blob/main/assets/images/ser_dog_2.png?raw=true" alt="dog playing">
                                        <div class="service_description">
                                          <h3 class="service_title">Training Aids:</h3>
                                          <p>
                                            Unlock Your Pet's Potential: Fun and Effective Training Aids for a Well-Behaved Companion!
                                          </p>
                                        </div>
                                      </div>
                                      <div class="service service_3">
                                        <img src="https://github.com/r-e-d-ant/DOG-guard-website/blob/main/assets/images/ser_dog_3.png?raw=true" alt="dog washing">
                                        <div class="service_description"> Accessories
                                          <h3 class="service_title">                  </h3>
                                          <p>Comfort, Style, and Safety Combined: The Perfect Accessories for Every Pet!</p>
                                        </div>
                                      </div>
                                    </div>
                                  </section>
<!-- SECTION 2 -->          
        



      
<!-- story SECTION 3 -->
                            <section id="about" class="section_3">
                                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
                                    <path fill-opacity=".5" d="M0,160L48,160C96,160,192,160,288,133.3C384,107,480,53,576,26.7C672,0,768,0,864,48C960,96,1056,192,1152,202.7C1248,213,1344,139,1392,101.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                                  </svg>


                            </section>
                            <section id="six">
                                    <h5>Our Story</h5>
                                    <h1>We started with one simple belief: pets deserve the same love and care in their food as humans. Inspired by our furry companions,THE PET PANTRY was born to deliver premium, wholesome meals that keep tails wagging and purrs going strong.</h1>
                            </section>
         
<!-- SECTION 3 ENDS -->    







<!-- SECTION 4 STARTS-->
                              <section id="testimonials" class="section_4 container">
                                <h2 class="testimony_title title">KNOW US...</h2>
                                <div class="testimonials">
                                  <div class="testimony testimony_1">
                                    <div class="tester">
                                      <div class="tester_profile"></div>
                                      <h3 class="tester_name title">What Drives Us</h3>
                                    </div>
                                    <p>
                                      At The Pet Pantry, we deliver nutritious, high-quality meals crafted with love to keep your pets happy and healthy. Committed to sustainability and giving back, we’re here to make every tail wag and every purr count!
                                    </p>
                                  </div>
             <!-- - -->
                                  <div class="testimony testimony_2">
                                    <div class="tester">
                                      <div class="tester_profile"></div>
                                      <h3 class="tester_name title">Our Commitment"</h3>
                                    </div>
                                    <p>
                                      At The Pet Pantry, we value Quality, Sustainability, Transparency, and Compassion, ensuring the best for your pets while caring for the planet and giving back to animal shelters.
                                    </p>
                                  </div>
             <!-- - -->
                                  <div class="testimony testimony_3">
                                    <div class="tester">
                                      <div class="tester_profile"></div>
                                      <h3 class="tester_name title">What We Offer</h3>
                                    </div>
                                    <p>
                                      grain-free, organic, tailored to specific breeds
                                    </p>
                                  </div>
             <!-- - -->
                                  <div class="testimony testimony_4">
                                    <div class="tester">
                                      <div class="tester_profile"></div>
                                      <h3 class="tester_name title">Making a Difference</h3>
                                    </div>
                                    <p>
                                      At The Pet Pantry, we’re dedicated to giving back by partnering with animal shelters, donating a portion of our profits to pet welfare organizations, and supporting pet adoption drives to help every pet find a loving home.
                                    </p>
                                  </div>
            <!-- - -->
                                </div>
                                <div class="bones">
                                  <i class="fas fa-bone bone1"></i>
                                  <i class="fas fa-bone bone2"></i>
                                  <i class="fas fa-bone bone_c"></i>
                                  <i class="fas fa-bone bone3"></i>
                                  <i class="fas fa-bone bone4"></i>
                                </div>
                              </section>
 <!-- SECTION 4 ENDS -->    
  
 






<!-- SECTION 5 -->
        

<!-- jumping cat -->
 
<?php
    // navbar connection
    include("footer.php");

?>
                      
<!-- SECTION 5 ENDS -->





</body>
</html>